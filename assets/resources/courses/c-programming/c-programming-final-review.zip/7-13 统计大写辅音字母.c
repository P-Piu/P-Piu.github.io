#include<stdio.h>
int main(){
	char str[81];
	gets(str);
	int i=0;int count=0;
	while(str[i]!='\0'){
		if(str[i]>='A'&&str[i]<='Z'&&str[i]!='A'&&str[i]!='E'&&str[i]!='I'&&str[i]!='O'&&str[i]!='U'){
			count++;
		} 
		i++;
	}
	printf("%d",count);
	return 0;
} 
