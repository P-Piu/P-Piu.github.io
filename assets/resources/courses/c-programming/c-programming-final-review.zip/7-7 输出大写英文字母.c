#include<stdio.h>
int main(){
	int a[26]={0};//��������˼�� �ǳ�ok 
	char str[81];
	gets(str);
	int i;int flag=0;
	for(i=0;str[i]!='\0';i++){
		if(str[i]>='A'&&str[i]<='Z'&&a[str[i]-'A']==0){
			a[str[i]-'A']=1;
			printf("%c",str[i]);
			flag=1;
		}
	}
	if (flag==0){
		printf("Not Found");
	}
	return 0;
}
