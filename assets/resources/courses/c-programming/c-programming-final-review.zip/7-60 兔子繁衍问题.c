#include<stdio.h>
int main(){
	int N;
	scanf("%d",&N);
	int prev1,prev2;int month;
	int current;
	prev1=1;prev2=1;
	if(N==1){
		printf("1");
	}
	else{
		for(month=3;;month++){
			current=prev1+prev2;
			if(current>=N){
				printf("%d",month);
				break;
			}
			prev1=prev2;
			prev2=current;
		}
		
	}
	return 0; 
	
}
