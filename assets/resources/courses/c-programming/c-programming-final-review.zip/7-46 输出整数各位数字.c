#include<stdio.h>
#include<math.h>
int main(){
	int i;
	int X;
	int n=0;
	scanf("%d",&X);
	int temp=X;
	while(X!=0){
		X=X/10;
		n++;
	}				//ͳ��X��λ�� 
	X=temp;
	while(X>10){
		temp=1;
		for(i=0;i<n-1;i++){
			temp*=10;
		}
		printf("%d ",X/temp);
		X=X%temp;
		n--;
	} 
	printf("%d ",X);
	return 0;
}

