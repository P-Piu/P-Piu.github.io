#include<stdio.h>
int main(){
	char str[81];
	gets(str);
	int i=0;
	while(str[i]!='\0'){
		if(str[i]>='A'&&str[i]<='Z'){
			str[i]='A'+'Z'-str[i];
		}
		i++;}
	printf("%s",str);
	return 0;	
}
