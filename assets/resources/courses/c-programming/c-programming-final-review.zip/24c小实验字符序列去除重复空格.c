#include<stdio.h>
int main(){
	char str[80];
	int i=0;char pre='1'; char now;
	now=getchar();
	while(now!='\n'){
		if(pre==' '&&now==' '){
			now=getchar();
			continue;
		}
		str[i]=now;
		i++;
		pre=now;
		now=getchar();
	}
	str[i]='\0';
	printf("%s",str);
	return 0;
} 
//12min
