#include<stdio.h>
#include<math.h>
int isprime(int n);
int main(){
	int a,b;int temp;int flag=0; 
	scanf("%d",&a);
	scanf("%d",&b);
	int i;
	if(a>b){
		temp=a;
		a=b;
		b=temp;
	}
	for(i=a;i<=b;i++){
		if(isprime(i)){
			flag=1;
			printf("%4d",i);
		}
	}
	if(flag==0){
		printf("No"); 
	}
	return 0;
	
}
int isprime(int n){
	int i;
	if(n==0||n==1){
		return 0;
	} 
	if(n==2){
		return 1;
	}
	for(i=2;i<=sqrt(n);i++){
		if (n%i==0){
			return 0;
		}
	}
	return 1;
	
} //��ʱ�˷��� 
