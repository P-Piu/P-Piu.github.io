#include<stdio.h>
int main(){
	int X;
	scanf("%d",&X);
	int count=0;
	int d1,d2,d3;
	for(d1=X/5;d1>=1;d1--){
		for(d2=X/2;d2>=1;d2--){
			for(d3=X;d3>=1;d3--){
				if(5*d1+2*d2+d3==X){
					count++;
					printf("fen5:%d, fen2:%d, fen1:%d, total:%d\n",d1,d2,d3,d1+d2+d3);
				}
			}
		}
	}
	printf("count = %d",count);
	return 0;
}
