#include<stdio.h>
#include<math.h>
int main(){
	int m;
	scanf("%d",&m);
	int i;
	int isprime=1;
	if(m==0||m==1){
		isprime=0;
	}
	else if(m==2){
		isprime=1;
	}
	else{
	for(i=2;i<=sqrt(m);i++){
		if(m%i==0){
		isprime=0;
		break;
		}
	}
   }
   if(isprime==1){
		printf("��"); 
	}
	else{
		printf("����"); 
	}
	return 0;
}

