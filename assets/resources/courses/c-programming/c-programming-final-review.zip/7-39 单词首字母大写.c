#include<stdio.h>
int main(){
	char str[80000];
	gets(str);
	int i;
	if(str[0]>='a'&&str[0]<='z'){
		str[0]=str[0]+'A'-'a';
	}
	for(i=1;str[i]!='\0';i++){
		if(str[i-1]==' '&&(str[i]>='a'&&str[i]<='z')){
			str[i]=str[i]+'A'-'a';
		}
	}
	printf("%s",str);
	return 0;
} 
