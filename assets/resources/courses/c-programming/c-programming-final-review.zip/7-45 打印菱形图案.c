#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int i;int j;
	for(i=1;i<=n/2+1;i++){
		for(j=0;j<n-(2*i-1);j++){
			printf(" ");
		}
		for(j=0;j<2*i-1;j++){
			printf("* ");
		}
		printf("\n");
	}
	int t;
	for(i=n/2+2;i<=n;i++){
		t=n-(2*(n+1-i)-1);
		for(j=0;j<t;j++){
			printf(" ");
		}
		t=2*(n+1-i)-1;
		for(j=0;j<t;j++){
			printf("* ");
		}
		printf("\n");
	}
	return 0;
} 
