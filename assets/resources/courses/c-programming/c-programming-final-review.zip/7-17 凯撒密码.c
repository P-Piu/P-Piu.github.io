#include<stdio.h>
int main(){
	char str[81];
	int i=0;int n;int flag=1;int temp;
	gets(str); 
	scanf("%d",&n);
	if(n<0){
		flag=-1;
		n=-n;
	}
	if(n>=26){
		n=n%26;
	}
	n=n*flag;
	for(i=0;str[i]!='\0';i++){
		if(str[i]>='a'&&str[i]<='z'){
			temp=str[i]+n;
			if(temp<'a'){
				temp+=26;
			} 
			else if(temp>'z'){
				temp-=26;
			}
			str[i]=temp;
		}
		else if(str[i]>='A'&&str[i]<='Z'){
			temp=str[i]+n;
			if(temp<'A'){
				temp+=26;
			} 
			else if(temp>'Z'){
				temp-=26;
			}
			str[i]=temp;
		}
	}
	printf("%s",str);
	return 0;
}
