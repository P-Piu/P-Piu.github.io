#include<stdio.h>
//�Ұ��� ����� ����С 
int main(){
	int n;
	scanf("%d",&n);
	int a[n][n];
	int i,j,k; int flag=0;
	int maxh;int minl;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			maxh=1;minl=1;
			for(k=0;k<n;k++){
				if(a[i][k]>a[i][j]){
					maxh=0;
					break;
				}
			}
			for(k=0;k<n;k++){
				if(a[k][j]<a[i][j]){
					minl=0;
					break;
				}
			}
			if(maxh&&minl){
				flag=1;
				printf("%d %d",i,j);
			}
		}
	}
	if(flag==0){
		printf("NONE");
	}
	return 0;
}
