#include<stdio.h>
#define ADD(x,y) x+y
#define MUL(x,y) (x*y)
#define POW(x) ((x)*(x))
int main(){
	int a=1,b=2;
	printf("%d %d %d",\
	b*ADD(a,ADD(3,2*b)*2),\
	MUL(ADD(a,b),ADD(b,a)),\
	POW(ADD(++a,3))); 
	return 0;
}
