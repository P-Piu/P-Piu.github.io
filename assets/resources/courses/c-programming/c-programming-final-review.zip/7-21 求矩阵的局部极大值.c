#include<stdio.h>
int main(){
	int M,N;
	scanf("%d%d",&M,&N);
	int a[M][N];
	int i,j; //���� 
	int flag=0;
	
	for(i=0;i<M;i++){
		for(j=0;j<N;j++){
			scanf("%d",&a[i][j]);
		}
	}						//���� 
	for(i=1;i<M-1;i++){
		for(j=1;j<N-1;j++){
			if(a[i][j]>a[i][j-1]&&a[i][j]>a[i][j+1]&&a[i][j]>a[i-1][j]&&a[i][j]>a[i+1][j]){
				flag=1;
				printf("%d %d %d\n",a[i][j],i+1,j+1);
			}
		}
	}				
	if(flag==0){
		printf("None %d %d",M,N);
	}
	return 0;
}
