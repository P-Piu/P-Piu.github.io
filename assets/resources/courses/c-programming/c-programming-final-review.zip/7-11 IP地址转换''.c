#include<stdio.h>
int main(){
	char a[33];
	int i,j;
	int sum;
	for(i=0;i<32;i++){
		scanf("%c",&a[i]);
	}
	a[i]='\0';
	for(i=0;i<=24;i=i+8){
	sum=0;
	for(j=i;j<i+8;j++){
		sum=sum*2+(a[j]-'0');
	}
	printf("%d",sum);
	if(i!=24){
		printf(".");
	}
	}
	return 0;
}
