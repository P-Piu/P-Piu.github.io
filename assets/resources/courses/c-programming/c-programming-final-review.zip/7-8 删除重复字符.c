#include<stdio.h>
#include<string.h>
int main(){
	char str1[81];
	char str2[81]={'\0'};
	int length;int alreadyin;
	gets(str1);
	int i=0;int j;
	char temp;
	while(str1[i]!='\0'){
		alreadyin=0;
		length=strlen(str2);
		for(j=0;j<length;j++){
			if(str1[i]==str2[j]){//ǧ��Ҫ����if����Ļ����� 
			alreadyin=1;
			break;}
		}
		if(alreadyin==0){
			str2[length]=str1[i];
		}
		i++; 
	}
	length=strlen(str2);
	str2[length]='\0';
	for(i=0;i<length-1;i++){
		for(j=0;j<length-1-i;j++){
			if(str2[j]>str2[j+1]){
				temp=str2[j];
				str2[j]=str2[j+1];
				str2[j+1]=temp; 
			}
		}
	}
	printf("%s",str2);
	return 0;
}
