#include<stdio.h>
int main(){
	int M,N;
	scanf("%d%d",&M,&N);
	int i;int count=0;
	int sum=0;
	for(i=M;i<=N;i++){
		if(isprime(i)==1){
			count++;
			sum+=i;
		}
	}
	printf("%d %d",count,sum);
	return 0;
}
int isprime(int n){
	int i;
	if(n==0||n==1){
		return 0;
	}
	if(n==2){
		return 1;
	}
	for(i=2;i*i<=n;i++){
		if(n%i==0){
			return 0;
		}
	}
	return 1;
}
