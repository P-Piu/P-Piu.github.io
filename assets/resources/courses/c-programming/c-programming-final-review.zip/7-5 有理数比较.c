#include<stdio.h>
int main(){
	int a1,b1,a2,b2;double t1,t2;
	scanf("%d/%d %d/%d",&a1,&b1,&a2,&b2);
	t1=a1*1.0/b1;
	t2=a2*1.0/b2;
	if(t1<t2){
		printf("%d/%d < %d/%d",a1,b1,a2,b2);
	}
	else if(t1>t2){
		printf("%d/%d > %d/%d",a1,b1,a2,b2);
	}
	else {
		printf("%d/%d = %d/%d",a1,b1,a2,b2);
	}
	return 0;
}
