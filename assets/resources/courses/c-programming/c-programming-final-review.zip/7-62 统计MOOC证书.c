#include<stdio.h>
int main(){
	int N;
	int i;
	int grade;
	int count[3]={0};
	scanf("%d",&N);
	for(i=0;i<N;i++){
		scanf("%d",&grade);
		if(grade>=85){
			count[0]++;
		}
		else if(grade>=60){
			count[1]++;
		}
		else{
			count[2]++;
		}
	}
	printf("%d %d %d",count[0],count[1],count[2]);
	return 0;
}
