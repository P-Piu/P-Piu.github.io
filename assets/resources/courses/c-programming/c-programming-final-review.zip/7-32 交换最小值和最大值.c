#include<stdio.h>
void swap(int *a,int *b); 
int main(){
	int N;
	scanf("%d",&N);
	int a[N];
	int i;
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	int indexmax=0;
	for(i=0;i<N;i++){
		if(a[indexmax]<a[i]){
			indexmax=i;
		}
	}
	swap(&a[N-1],&a[indexmax]);
	int indexmin=0;
	for(i=0;i<N;i++){
		if(a[indexmin]>a[i]){
			indexmin=i;
		}
	}
	swap(&a[0],&a[indexmin]);
	for(i=0;i<N;i++){
		printf("%d ",a[i]);
	}
	return 0;
}
void swap(int *a,int *b){
	int t;
	t=*a;
	*a=*b;
	*b=t;
}
