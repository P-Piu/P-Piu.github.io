#include<stdio.h>
#include<string.h>
int main(){
	char str[81];
	gets(str);
	char revert[81];
	int length=strlen(str);
	int i;
	for(i=0;i<length;i++){  
		revert[i]=str[length-1-i];
	}
	revert[length]='\0';
	printf("%s",revert);
	return 0;
}
