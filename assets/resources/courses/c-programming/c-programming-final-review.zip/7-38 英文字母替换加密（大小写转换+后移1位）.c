#include<stdio.h>
int main(){
	char ch;
	while((ch=getchar())!='\n'){
		if(ch=='z'){
			putchar('A');
		}
		else if(ch=='Z'){
			putchar('a');
		}
		else if(ch>='a'&&ch<'z'){
			ch=ch+1;
			ch=ch+'A'-'a';
			putchar(ch);
		}
		else if(ch>='A'&&ch<'Z'){
			ch=ch+1;
			ch=ch+'a'-'A';
			putchar(ch);
		}
		else{
			putchar(ch);
		}
	}
	return 0;
}
