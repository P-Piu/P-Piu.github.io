#include<stdio.h>
int main(){
	char ch;char prev=' ';int hasword=0;
	int len=0;
	while((ch=getchar())!='\n'){
		if(ch!=' '){
			len++;
			prev=ch;
			hasword=1;
		}
		else if(ch==' '&&prev!=' '){
			printf("%d ",len);
			len=0;
			prev=ch;
		}
		else{
			prev=ch;
		}
		}
	if(len!=0){
	printf("%d ",len);}
	if(hasword==0){
		printf("0 ");
	}
	return 0;
}
