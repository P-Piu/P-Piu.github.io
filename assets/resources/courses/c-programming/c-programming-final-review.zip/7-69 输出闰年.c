#include<stdio.h>
//���꣺year%4==0&&year%100!=0||year%400=0
int main(){
	int year;
	int i;
	int flag=0;
	scanf("%d",&year);
	if(!(year>=2001&&year<=2100)){
		printf("Invalid year!");
	}
	else{
	for(i=2001;i<=year;i++){
		if(i%4==0&&i%100!=0||i%400==0){
			flag=1;
			printf("%d\n",i);
		}
	}
	if(flag==0){
		printf("None");
	}
	}
	return 0;
} 
