#include<stdio.h>
int main(){
	int count[10]={0};
	int N;
	scanf("%d",&N);
	int a[N];
	int i;
	int n;
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<N;i++){
		n=a[i];
		while(n!=0){
			count[n%10]++;
			n=n/10;
		}
	}
	int max;
	max=count[0];
	for(i=1;i<10;i++){
		if(count[i]>max){
			max=count[i];
		}
	}
	printf("%d:",max);
	for(i=0;i<10;i++){
		if(count[i]==max){
			printf(" %d",i); 
		}
	}
	return 0;
} 
