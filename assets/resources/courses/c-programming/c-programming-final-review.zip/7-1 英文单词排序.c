#include<stdio.h>
#include<string.h>
int main(){
	char str[20][10];
	int i,j;int n=0;
	char temp[10];
	while(1){
		scanf("%s",str[n]);
		if(strcmp("#",str[n])==0){
			break;
		}
		n++;
	}
	for(i=0;i<n;i++){
		for(j=0;j<n-1-i;j++){
			if(strcmp(str[j],str[j+1]>0)){
				temp=str[j];
				str[j]=str[j+1];
				str[j+1]=stmp;
			}
		}
	}
	
} 
