#include<stdio.h>
int main(){
	int N1,N2;int alreadyin;
	scanf("%d",&N1);
	int a[N1];
	int i,j;int flag;
	for(i=0;i<N1;i++){
		scanf("%d",&a[i]);
	} 
	scanf("%d",&N2);
	int b[N2];
	for(i=0;i<N2;i++){
		scanf("%d",&b[i]);
	}
	int t=N1+N2;
	int c[t];int k=0;
	for(i=0;i<N1;i++){
		flag=1; alreadyin=0;//��Ϊ���Ԫ�ز��ظ� 
		for(j=0;j<N2;j++){
			if(a[i]==b[j]){
				flag=0;//���Ԫ���ظ� 
				break;
			}
		}
		if(flag==1){
			for(j=0;j<k;j++){
				if(c[j]==a[i]){
					alreadyin=1;
					break;
				}
			}
			if(alreadyin==0){
			c[k]=a[i];
			k++;}
		}
	}
	for(i=0;i<N2;i++){
		flag=1;alreadyin=0;
		for(j=0;j<N1;j++){
			if(b[i]==a[j]){
				flag=0;
				break;
			}
		}
		if(flag==1){
			for(j=0;j<k;j++){
				if(b[i]==c[j]){
					alreadyin=1;
					break;
				}
			}
			if(alreadyin==0){
			c[k]=b[i];
			k++;}
		}
	}
	for(i=0;i<k;i++){
		printf("%d",c[i]);
		if(i!=k-1){
			printf(" ");
		}
	}
	return 0;	
} 
