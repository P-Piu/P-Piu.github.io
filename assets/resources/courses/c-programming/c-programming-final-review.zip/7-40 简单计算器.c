#include<stdio.h>
int main(){
	int num=0; char op; 
	char ch;int result=0;
	ch=getchar();
	while(ch>='0'&&ch<='9'){
		num=num*10+(ch-'0');
		ch=getchar();
	}
	result=num;//�����һ�����ֲ�������result�� 
	op=ch;//������һ������� 
	while(op!='='){
		num=0;
		ch=getchar();
		while(ch>='0'&&ch<='9'){
			num=num*10+(ch-'0');
			ch=getchar();
		}
		if(op=='+'){
			result+=num;
			op=ch;
		}
		else if(op=='-'){
			result-=num;
			op=ch;
		}
		else if(op=='*'){
			result*=num;
			op=ch;
		}
		else if(op=='/'){
			if(num==0){
				printf("ERROR");
				return 0;
			}
			else{
				result/=num;
				op=ch;
			}
		}
		else{
			printf("ERROR");
			return 0;
		}
	}
	printf("%d",result);
	return 0;
}
