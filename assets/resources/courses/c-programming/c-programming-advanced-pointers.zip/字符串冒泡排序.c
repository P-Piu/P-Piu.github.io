#include<stdio.h>
#include<string.h>
void fsort(char* a[],int n);
int main(){
	char* a[5]={"red","blue","yellow","green","black"};
	fsort(a,5);
	int i;
	for(i=0;i<5;i++){
		printf("%s\n",a[i]);
	}
	return 0;
}
void fsort(char* a[],int n){
	int i;int j;char * temp;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(strcmp(a[j],a[j+1])>0){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
}
