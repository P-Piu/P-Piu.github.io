#include<stdio.h>
int main(int argc,char*argv[]){
	int k;
	for(k=1;k<argc;k++){		//���߿���д�� for(k=1,argv++;k<argc;k++)  
		printf("%s",argv[k]); 	//             printf("%s",*(argv++));
		printf("\n");
	}
	return 0; 
}
