#include<stdio.h>
#include<string.h>
#include<stdlib.h>
void fsort(char*a[],int n);
int main(){
	char str[11];
	char *p[20];
	int n=0;
	int i,j;
	gets(str);
	while(str[0]!='#'){
		p[n]=(char *)malloc(sizeof(char)*(strlen(str)+1));
		strcpy(p[n],str);
		gets(str); 
		n++;
	}//����n���ַ��� ���ַ�ָ������p����֯���� 
	fsort(p,n);
	for(i=0;i<n;i++){
		printf("%s ",p[i]);
		free(p[i]);
	}
	return 0;
}
void fsort(char*a[],int n){
	int i,j;char *temp;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(strlen(a[j])>strlen(a[j+1])){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
}
