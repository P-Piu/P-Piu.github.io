#include<stdio.h>
void fsort(int a[],int n);
int main(){
	int a[5]={6,5,2,8,1};
	int i;
	fsort(a,5);
	for(i=0;i<5;i++){
		printf("%d",a[i]);
	}
	return 0;
}
	void fsort(int a[],int n){
		int i,j;int temp; 
		for(i=0;i<n-1;i++){
			for(j=0;j<n-1-i;j++){
				if(a[j]>a[j+1]){
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
	}
