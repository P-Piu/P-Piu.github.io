#include<stdio.h>
int main(){
	char poem[4][25];
	int i,j;
	for(i=0;i<4;i++){
		gets(poem[i]);
	}
	for(i=0;i<4;i++){
		for(j=0;j<3;j++){
			putchar(poem[i][j]);
		}
	}
	return 0;
}
