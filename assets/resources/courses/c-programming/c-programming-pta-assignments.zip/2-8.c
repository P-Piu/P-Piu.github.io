#include<stdio.h>
int main(){
	int n,i,flag=1;double sum=0;
	scanf("%d",n);
	for(i=1;i<=n;i++,flag*=-1)
	{sum+=1.0/(2*n-1)*flag;
	}
	return 0;
}
