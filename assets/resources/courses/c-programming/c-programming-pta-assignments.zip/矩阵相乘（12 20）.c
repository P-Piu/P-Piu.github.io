#include<stdio.h>
#include<stdlib.h>
int main(){
	int Ra,Ca,Rb,Cb;
	scanf("%d%d",&Ra,&Ca);
	int i,j;
	int **a=(int**)malloc(Ra*sizeof(int*));
	for(i=0;i<Ra;i++){
		a[i]=(int*)malloc(Ca*sizeof(int));
	}
	for(i=0;i<Ra;i++){
		for(j=0;j<Ca;j++){
			scanf("%d",&a[i][j]);
		}
	}
	scanf("%d%d",&Rb,&Cb);
	int **b=(int**)malloc(Rb*sizeof(int*));
	for(i=0;i<Rb;i++){
		b[i]=(int*)malloc(Cb*sizeof(int));}
	for(i=0;i<Rb;i++){
		for(j=0;j<Cb;j++){
			scanf("%d",&b[i][j]);
		}
	}
	int **c=(int**)malloc(Ra*sizeof(int*));
	for(i=0;i<Ra;i++){
		c[i]=(int*)malloc(Cb*sizeof(int));}
	if(Ca!=Rb){
		printf("Error: %d != %d",Ca,Rb);
	}
	else{
		int k;int sum;
		for(i=0;i<Ra;i++){
			for(j=0;j<Cb;j++){
				sum=0;
				for(k=0;k<Ca;k++){
					sum+=a[i][k]*b[k][j];
				}
				c[i][j]=sum;
			}
		}
		
	}
	printf("%d %d\n",Ra,Cb);
	for(i=0;i<Ra;i++){
			printf("%d",c[i][0]);
			for(j=1;j<Cb;j++){
			printf(" %d",c[i][j]);
			}
			printf("\n");
		}
	return 0;}


