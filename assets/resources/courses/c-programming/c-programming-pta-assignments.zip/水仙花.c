#include<stdio.h>
#include<math.h>
int main(){
	int N;int n=0;int x;int sum=0;int i;int t;
	scanf("%d",&N); 
	for(x=pow(10,N-1);x<=pow(10,N)-1;x++){
		sum=0;
		t=x;
	    for(i=N;i>=1;i--){
		sum+=(int)pow(t%10,N);
		t=t/10; }
		if (x==sum)
		printf("%d\n",x);
	
}}
