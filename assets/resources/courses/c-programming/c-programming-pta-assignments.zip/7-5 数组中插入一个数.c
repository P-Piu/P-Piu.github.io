#include<stdio.h>
int main(){
	int x;int i;int j;
	int a[11]={1, 2, 4, 6, 8, 9, 12, 15, 149, 156};
	scanf("%d",&x);
	if(x<1){
		for(i=9;i>=0;i--){
			a[i+1]=a[i];
		}
		a[0]=x;
	}
	else 	if(x>156){
		          a[10]=x;
        	}
  			else
				for(i=0;i<10;i++){
					if(x<=a[i]){
						for(j=9;j>=i;j--){
							a[j+1]=a[j];
						}
						a[i]=x;
						break;
					}
				}
	for(i=0;i<11;i++){
		printf("%5d",a[i]);
	}
	return 0;
		
	
	
} 
