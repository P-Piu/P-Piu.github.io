#include<stdio.h>
int main(){
	int N;int i,j;int num=1;
	scanf("%d",&N);
	int top=0,bottom=N-1,left=0,right=N-1;
	int a[N][N];
	while(num<=N*N){
	for(j=left;j<=right;j++){
		if(num<=N*N){
		a[top][j]=num;
		num++;}
	}
	top++;
	for(i=top;i<=bottom;i++){
		if(num<=N*N){
		a[i][right]=num;
		num++;}
	}
	right--;
	for(j=right;j>=left;j--){
		if(num<=N*N){
		a[bottom][j]=num;
		num++;}
	}
	bottom--;
	for(i=bottom;i>=top;i--){
		if(num<=N*N){
		a[i][left]=num;
		num++;}
	}
	left++;}
	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			printf("%3d",a[i][j]);
		} 
		printf("\n");
	} 
}
