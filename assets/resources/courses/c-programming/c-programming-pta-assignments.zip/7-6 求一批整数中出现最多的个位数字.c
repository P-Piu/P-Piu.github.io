#include<stdio.h>
int main(){
	int N;int M;int i;int j;int temp=10;
	scanf("%d",&N);
	int a[N];
	int b[10]={0};
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
		if(a[i]==0)
		b[0]++;
		while(a[i]>0){
		b[a[i]%temp]++;
		a[i]/=10;
		}
	}
		M=b[0];
	for(j=1;j<10;j++){
		if(b[j]>M)
		M=b[j];}
	printf("%d:",M);
	for(j=0;j<10;j++){
		if(b[j]==M)
		printf(" %d",j);
	}
	return 0;
	
} 
