#include<stdio.h>
double fact(int x);
int main(){
	
	int m,n;double result;
	scanf("%d%d",&m,&n);
	result=fact(n)/(fact(m)*fact(n-m));
	printf("result = %.0f",result);
	return 0;
}
double fact(int x){
	int i;double product=1;
	for(i=1;i<=x;i++)	
		product*=i;
		return product;	}
