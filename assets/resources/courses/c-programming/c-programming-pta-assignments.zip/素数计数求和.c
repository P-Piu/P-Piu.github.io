#include<stdio.h>
int sushu(int x);
int main(){
	int M,N,i,sum=0,counter=0;
	scanf("%d%d",&M,&N);
	for(i=M;i<=N;i++)
	{  if(sushu(i))
	   {sum+=i;
	   counter+=1;}
	}
	printf("%d %d",counter,sum);
	return 0;
}


int sushu(int x){
	int j,Sum=0;
	for(j=1;j<=x;j++){
	    if (x%j==0)
	    Sum+=j;}
	if(Sum==x+1)
	   return 1;
	else return 0;}

