#include<stdio.h>
int main(){
	int m,n;int result;int temp;
	scanf("%d%d",&m,&n);
	if(m%n==0){
	    result=n;
	    printf("%d",n);}
	else{
		while(temp!=0){
			m=n;
			n=temp;
			temp=m%n;
	
	}
		printf("%d",n);
	}
	return 0;
}
