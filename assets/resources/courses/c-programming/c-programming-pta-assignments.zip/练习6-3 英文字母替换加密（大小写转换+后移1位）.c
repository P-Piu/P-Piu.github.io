#include<stdio.h>
#define MAXLINE 80
#define M 26
int main(){
	char str[MAXLINE];
    int i;
    i=0;
	while((str[i]=getchar())!='\n'){
		i++;
	}
	str[i]='\0';
	for(i=0;str[i]!='\0';i++){
		if(str[i]>='a'&&str[i]<='z'){
		   if(str[i]+1>'z'){
		   	 str[i]=str[i]+1-M;
		   }
		   else{
		   	str[i]=str[i]+1;
		   }
		   str[i]+='A'-'a';
		}
		else if(str[i]>='A'&&str[i]<='Z'){
		   if(str[i]+1>'Z'){
		   	 str[i]=str[i]+1-M;
		   }
		   else{
		   	str[i]=str[i]+1;
		   }
		   str[i]+='a'-'A';
		}
	}
	puts(str);
	return 0;
}
