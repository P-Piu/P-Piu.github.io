#include<stdio.h>
#include<math.h>
int main(){
	int x;int i;int isprime=1;
	scanf("%d",&x);
	if(x<=1)
	isprime=0; 
	for(i=2;i<=sqrt(x);i++){
	      	if(x%i==0){
		              isprime=0;
			          break;
	                        }
	}
	printf("%d",isprime);
}
