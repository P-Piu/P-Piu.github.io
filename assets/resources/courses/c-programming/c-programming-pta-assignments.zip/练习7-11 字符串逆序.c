#include<stdio.h>
#define MAXLINE 81

int main(){
	int len(char* p);
	char str[MAXLINE];
	int i;
	i=0;
	while( ( str[i]=getchar() )!= '\n' ){
		i++;
	}
	str[i]='\0';
	for(i=len(str)-1;i>=0;i--){
		putchar(str[i]);
	}
}
int len(char* p){
	int len=0;
	while(*p!='\0'){
		len++;
		p++;
	}
	return len;
}
