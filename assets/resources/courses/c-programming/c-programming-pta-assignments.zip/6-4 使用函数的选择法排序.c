void sort( int a[], int n );
#include <stdio.h>
#define MAXN 10

void sort( int a[], int n );

int main()
{
    int i, n;
    int a[MAXN];
    
    scanf("%d", &n);
    for( i=0; i<n; i++ )
        scanf("%d", &a[i]);

    sort(a, n);

    printf("After sorted the array is:");
    for( i = 0; i < n; i++ )
        printf(" %d", a[i]);
    printf("\n");
        
    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */
void sort( int a[], int n ){
	int i; int min; int j;int temp; int index;
	for(i=0;i<n-1;i++){
		min=a[i]; index=i;
		for(j=i+1;j<n;j++){
			if(a[j]<min){
				min=a[j];
				index=j;
			}
		}
		temp=a[i];
		a[i]=a[index];
		a[index]=temp;
		}
		}
		
		
		
		

