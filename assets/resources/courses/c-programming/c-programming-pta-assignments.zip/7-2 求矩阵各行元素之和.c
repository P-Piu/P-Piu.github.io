#include<stdio.h>
int main(){
	int M,N;int i,j;int sum;
	scanf("%d%d",&M,&N);
	int a[M][N];
	for(i=0;i<M;i++){
		for(j=0;j<N;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<M;i++){
		sum=0;
		for(j=0;j<N;j++){
			sum+= a[i][j];
			}
		printf("%d\n",sum);
		
		}
		return 0;
	}
