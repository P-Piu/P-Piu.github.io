#include<stdio.h>
int main(){
	int N;int M;int i;int j; 
	scanf("%d%d",&M,&N);
	if(M>N){
		M=M%N;
	} 
	int a[N][N+M];
	for(i=0;i<N;i++){
		for(j=M;j<N+M;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<N;i++){
		for(j=N;j<N+M;j++){
			a[i][j-N]=a[i][j];
		}
	}
	for(i=0;i<N;i++){
	              for(j=0;j<N;j++){
	              printf("%d ",a[i][j]);}
	              printf("\n");	}
 	
	return 0;
}
