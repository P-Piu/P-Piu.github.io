#include <stdio.h>
int main(){
printf("%d,%d,%d",NULL, '\0',EOF);}

