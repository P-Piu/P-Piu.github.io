#include<stdio.h>
void swap(int *a,int *b);
int main(){
	int k;
	int a[4][5];
	int i,j;
	for(i=0;i<4;i++){
		for(j=0;j<5;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(j=0;j<5;j++){
		for(k=0;k<6;k++)
		{for(i=0;i<3;i++){
			if(a[i][j]>a[i+1][j]){
				swap(&a[i][j],&a[i+1][j]);
			}
		}}
	}
	for(i=0;i<4;i++){
		for(j=0;j<5;j++){
			printf("%4d",a[i][j]);
		}
		printf("\n");}
	return 0;
} 
void swap(int *a,int *b){
	int t;
	t=*a;
	*a=*b;
	*b=t;
}
