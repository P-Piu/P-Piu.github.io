#include<stdio.h> 
int main(){
    double height;
    height=1/2.0*10*3*3;
    printf("height = %.2f",height);
    return 0;}
