#include<stdio.h>
int main(){
	int x;int number;int ret=0;
	scanf("%d",&x);
	if(x<0){     x*=-1;
	             printf("-");
	             do{  number=x%10;
                 x=x/10;
                 ret=ret*10+number;
		         printf("%d",number);}
			     while(x>0); 
			     ret*=-1; 
			     printf("\n");
	}
	else{
	 do{  number=x%10;
          x=x/10;
		  printf("%d",number);
		  ret=ret*10+number;}
	      while(x>0);
		  printf("\n"); }
	      
	printf("%d\n",ret);
	return 0;
}
