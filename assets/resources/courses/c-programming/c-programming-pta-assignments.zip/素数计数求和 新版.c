#include<stdio.h>
#include<math.h>
int main(){
	int Isprime(int x);
	int i;
	int M,N;
	int sum=0;int n=0;
	scanf("%d%d",&M,&N);
	for(i=M;i<=N;i++){
	         	if(Isprime(i)){
	        	sum+=i;
		        n++;}
            	}
    printf("%d %d",n,sum) ;  
    return 0; 
      
 }





int Isprime(int x){
	int i;int isprime=1;
	if(x<=1)
	isprime=0; 
	for(i=2;i<=sqrt(x);i++){
	      	if(x%i==0){
		              isprime=0;
			          break;
	                        }
	}
     return isprime;
}
