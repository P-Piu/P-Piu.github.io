#include<stdio.h>
#define MAXLINE 80
void zip(char* p);
int main(){
	char line[MAXLINE];
	gets(line);
	zip(line);
	puts(line);
	return 0; 
} 
void zip(char *p){
char *q=p;
char temp;
int n;
while(*p!='\0'){
	n=1;
	while(*p==*(p+n)){
	n++;}
	temp=*p;
	if(n>=10){
		*q=n/10+'0';
		q++;
		*q=n%10+'0';
		q++;
	}
	else if(n>=2){
		*q=n+'0';
		q++;
	}
	*q=temp;
	p=p+n;
	q++;
}
*q='\0';}



