#include<stdio.h>
int main()
{   int m,g,s,b,n;
    scanf("%d",&m);
    b=m/100;
    s=(m-b*100)/10;
    g=(m-b*100)%10;
    n=g*100+s*10+b;
    printf("%d",n);
    return 0;
}
