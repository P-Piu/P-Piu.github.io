#include<stdio.h>
int main(){
	char ch; char prev=' ';
	while(1){
		ch=getchar();
		if(ch=='\n'){
			break;
		}
		if(prev==' '&&(ch>='a'&&ch<='z')){
			ch=ch+'A'-'a'; 
		}
		putchar(ch);
		prev=ch;
	}
	return 0;
}
