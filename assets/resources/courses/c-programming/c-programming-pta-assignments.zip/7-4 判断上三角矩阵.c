#include<stdio.h>
int main(){
	int T;int k; int n;int yes=1;int j;int i;
	scanf("%d",&T);
	for(k=0;k<T;k++){
		scanf("%d",&n);
		int a[n][n];
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(i=1;i<n;i++){
			for(j=0;j<i;j++){
				if(a[i][j]!=0){
					yes=0;
				}
			}}
		if(yes==1)
		printf("YES\n");
		else
		printf("NO\n");
		yes=1;
	}
	return 0;
}
