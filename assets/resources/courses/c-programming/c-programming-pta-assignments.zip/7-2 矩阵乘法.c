#include<stdio.h>
int main(){
	int n,m,k;int sum;int t;
	scanf("%d%d%d",&n,&m,&k);
	int a[n][m];
	int b[m][k];
	int c[n][k];
	int i,j;
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<m;i++){
		for(j=0;j<k;j++){
			scanf("%d",&b[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<k;j++){
			sum=0;
			for(t=0;t<m;t++){
				sum+=a[i][t]*b[t][j];
			}
			c[i][j]=sum;
		}
	}
	for(i=0;i<n;i++){
		printf("%d",c[i][0]);
		for(j=1;j<k;j++){
			printf(" %d",c[i][j]);
		}
		printf("\n");
	}
	return 0;
	
	
}
