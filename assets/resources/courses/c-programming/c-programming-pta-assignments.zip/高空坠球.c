#include<stdio.h>
int main(){
	int h0;int n;double s=0;int i;double h;
	scanf("%d%d",&h0,&n);
	if(n==0)
	printf("0.0 0.0");
	else{
	s=h0;
	h=h0/2.0;
	for(i=2;i<=n;i++){
		s+=h*2;
		h=h/2;
	}
	printf("%.1f %.1f",s,h);}
	return 0;
}
