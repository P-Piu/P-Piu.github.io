#include<stdio.h>
int main(){
	int a,b;
	if(a=5)
    printf("hahaha");	
    if(b=0)
    printf("hahahaha");
    else
    printf("wuwuwu"); 
    return 0;
}
