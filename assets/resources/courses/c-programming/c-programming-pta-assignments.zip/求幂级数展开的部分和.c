#include<stdio.h>
#include<math.h>
int main(){
	double jie(int j);
	double x;double sum=1;int i=1;double t;
	scanf("%lf",&x);
	do{ t=pow(x,i)/jie(i);
	    sum+=t;
     	i++;}
	while(t>=0.00001);
    printf("%.4f",sum);
} 
double jie(int j){
	double s=1;int i;/*������� ��double s*/
	for(i=1;i<=j;i++){
		s*=i; 
	} 
	return s;
}
