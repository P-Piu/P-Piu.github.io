#include<stdio.h>
void swap(int *px,int *py);
int main(){
	int N; int K;int i;int j;
	scanf("%d%d",&N,&K);
	int a[N];
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	for(j=0;j<K;j++){
	for(i=0;i<N-1;i++){
		if(a[i]>a[i+1]){
			swap(&a[i],&a[i+1]);
		}
	}
}
printf("%d",a[0]);
    	for(i=1;i<N;i++){
	printf(" %d",a[i]);
	}
	
}

void swap(int *px,int *py){
	int t;
	t=*px;
	*px=*py;
	*py=t;
}
