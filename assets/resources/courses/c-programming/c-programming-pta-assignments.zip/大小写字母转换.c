#include<stdio.h>
int main(){
	char s,prev;
	prev=' ';
    while(1)
    {scanf("%c",&s);
     if(s=='\n')
     break;
     else if(s>='a'&&s<='z'&&prev==' '){
    	  s=s-32;
    	  printf("%c",s);}
          else printf("%c",s);
     prev=s;}
}
