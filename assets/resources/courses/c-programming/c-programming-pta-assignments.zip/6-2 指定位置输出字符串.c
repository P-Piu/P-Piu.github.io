#include <stdio.h>
#define MAXS 10

char *match( char *s, char ch1, char ch2 );

int main()
{
    char str[MAXS], ch_start, ch_end, *p;
    scanf("%s\n", str);
    scanf("%c %c", &ch_start, &ch_end);
    p = match(str, ch_start, ch_end);
    printf("%s\n", p);

    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */
char *match( char *s, char ch1, char ch2 ){
	int i;int index;int foundch1=0;//index��Ϊch1�Ķ�Ӧ�±� 
	for(i=0;s[i]!='\0';i++){
		if (s[i]==ch1){
			index=i;
			foundch1=1;
			break;
		}}
	if(foundch1==0){
		printf("\n");
		return &s[i];
	} 
	for(i=index;s[i]!=ch2&&s[i]!='\0';i++){
		printf("%c",s[i]);
	}
    if(s[i]==ch2){
    	printf("%c",s[i]);
    }
    printf("\n");

	return (s+index); 
}
