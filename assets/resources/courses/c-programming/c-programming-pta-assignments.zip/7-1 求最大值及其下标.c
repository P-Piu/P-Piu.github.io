#include<stdio.h>
int main(){
	int n;int a[n];int max;int maxnumber;int i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	
	max=a[0];
	maxnumber=0;
	for(i=1;i<n;i++){
		if(a[i]>max)
		{max=a[i];
		 maxnumber=i;
		}
	}
	printf("%d %d",max,maxnumber);
	return 0;
}
