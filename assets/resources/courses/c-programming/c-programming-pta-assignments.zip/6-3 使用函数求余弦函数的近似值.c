#include <stdio.h>
#include <math.h>

double funcos( double e, double x );

int main()
{    
    double e, x;

    scanf("%lf %lf", &e, &x);
    printf("cos(%.2f) = %.6f\n", x, funcos(e, x));
    
    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */
double funcos( double e, double x ){
	int n=1;double jie;
	int k; 
	int i;
	int flag=1;
	double result=0;
	double final=e;
	while(fabs(final)>=e){
	jie=1;
	k=2*n-2;
	for(i=1;i<=k;i++){
		jie*=i;
	}
	final=flag*pow(x,k)/jie;
	flag*=-1;
	result+=final;
	n++;
	}
	return result;
}
