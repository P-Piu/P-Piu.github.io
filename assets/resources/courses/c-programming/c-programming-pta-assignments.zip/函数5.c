#include <stdio.h>
#define TOL 1E-3

double dist( double h, double p );

int main()
{
    double h, p, d;
    scanf("%lf %lf", &h, &p);
    d = dist(h, p);
    printf("%.6f\n", d);
    return 0;
}

double dist(double h,double p){
	double d=0,s=h;
	while(s>=TOL)
	{s=h/p;
	d+=h+s;
	h=s;
	}
	return d;
}

