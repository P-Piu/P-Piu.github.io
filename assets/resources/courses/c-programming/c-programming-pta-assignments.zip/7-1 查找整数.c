#include<stdio.h>
int main(){
	int N,X;int found=0;int i;
	scanf("%d%d",&N,&X);
	int a[N];
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
		if (a[i]==X){
			found=1;
			printf("%d",i);
		}
	}
	if(found==0){
		printf("Not Found");
	}
	return 0;
	
}
