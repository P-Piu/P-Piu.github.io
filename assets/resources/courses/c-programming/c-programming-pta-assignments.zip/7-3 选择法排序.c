#include<stdio.h>
int main(){
	int N;int i;int j;
	scanf("%d",&N);
	int a[N];
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	for(j=0;j<N-1;j++){
		for(i=j+1;i<N;i++){
			int t;
			if(a[i]>a[j]){
				t=a[j];
				a[j]=a[i];
				a[i]=t;
			}
			
		}
	}
	for(i=0;i<N-1;i++){
		printf("%d ",a[i]);
	}
	printf("%d",a[i]);
	
	return 0;
}
