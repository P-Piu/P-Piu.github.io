#include<stdio.h>
int maxh(int n,int i,int j,int(*a)[n]);
int minl(int n,int i,int j,int(*a)[n]);
int main(){
	int n;
	scanf("%d",&n);
	int a[n][n];
	int i,j;
	int flag=0;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(maxh(n,i,j,a)&&minl(n,i,j,a)){
				flag=1;
				printf("%d %d",i,j);
				break;
			}
		}
		if(flag==1){
			break;
		}
	}
	if(flag==0){
		printf("NONE");
	}
	return 0;
}
int maxh(int n,int i,int j,int(*a)[n]){
	int k;
	for(k=0;k<n;k++){
		if(a[i][j]<a[i][k]){
			return 0;
		}
	}
	return 1;
}
int minl(int n,int i,int j,int(*a)[n]){
	int k;
	for(k=0;k<n;k++){
		if(a[k][j]<a[i][j]){
			return 0;
		}
	}
	return 1;
}

