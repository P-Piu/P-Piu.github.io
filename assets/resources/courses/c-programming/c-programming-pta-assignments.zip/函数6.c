#include <stdio.h>
#define TOL 1E-3

double dist( double h, double p );

int main()
{
    double h, p, d;
    scanf("%lf %lf", &h, &p);
    d = dist(h, p);
    printf("%.6f\n", d);
    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */

double dist(double h,double p){
	double d=0,back=h;
	d+=h;
	while(back*p>=TOL){
		back=back*p;
		d+=back*2;
	}
	return d; 
	}
	

