#include<stdio.h>
struct time{
	int hour;
	int min;
	int second;
}; 
int main(){
	int n;
	struct time t;
	scanf("%d:%d:%d",&t.hour,&t.min,&t.second);
	scanf("%d",&n);
	t.second+=n;
	if(t.second>=60){
		t.min+=1;
		t.second-=60;
		if(t.min>=60){
			t.min-=60;
			t.hour+=1;
			if(t.hour>=24){
				t.hour-=24;
			}
		}
	}
	printf("%*2d:%*2d:%*2d",t.hour,t.min,t.second);
	return 0;
}
