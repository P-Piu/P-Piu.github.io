#include <stdio.h>
#define MAXN 10

void f( long int x, char *p );

int main()
{
    long int x;
    char s[MAXN] = "";
    
    scanf("%ld", &x);
    f(x, s);
    printf("%s\n", s);
    
    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */
void f( long int x, char *p ){
	int chu;int yu;int i=0;char t;int n;int flag=1;
	if(x<0){
		flag=0;
		x=-x;
	}

	while(x>=16){
	   yu=x%16;
	   if(yu<10){
	   	t='0'+yu;}
		else if(yu>=10){
			t='A'+yu-10;
		}
		p[i]=t;
	   x=x/16;
	   i++;
	}
	if(x<10){
		p[i]='0'+x;
	}
	if(x>=10){
		p[i]='A'+x-10;
	}
	n=i+1;
	p[n]='\0';
	char q[n];
	for(i=0;i<n;i++){
		q[i]=p[n-1-i];
	}
	q[n]='\0';
	if (flag==1){
	for(i=0;i<=n;i++){
		p[i]=q[i];
	}}
	else if(flag==0){
	p[0]='-';
	for(i=1;i<=n+1;i++){
		p[i]=q[i-1];
	}
	}
}
