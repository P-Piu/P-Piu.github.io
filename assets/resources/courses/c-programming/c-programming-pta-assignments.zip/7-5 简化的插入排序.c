#include<stdio.h>
int main(){
	int N;int i;int X;int j;
	scanf("%d",&N);
	int a[N+1];
	for (i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	scanf("%d",&X);
	    if(X<=a[0]){
		for(j=N-1;j>=0;j--){
			a[j+1]=a[j];
			
		}
		a[0]=X;
     	}
	    else if(X>=a[N-1]){
     	a[N]=X;
		 }
     	else {  for(i=0;i<N-1;i++){
	            if(X>=a[i]&&X<=a[i+1]){
		                 for(j=N-1;j>=i+1;j--){
			             a[j+1]=a[j];
			               }
			    a[i+1]=X;
			    break;
                      	}
	
     	}}
	for (i=0;i<N+1;i++){
		printf("%d ",a[i]);
	}
	return 0;
	
}
