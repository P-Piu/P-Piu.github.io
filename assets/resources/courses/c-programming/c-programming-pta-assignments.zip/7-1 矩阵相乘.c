#include<stdio.h>
int main(){
	int Ra,Ca,Rb,Cb;
	int i,j;
	scanf("%d%d",&Ra,&Ca);
	int **a = malloc(Ra * sizeof(int*));
    for (i = 0; i < Ra; i++) {
    a[i] = malloc(Ca * sizeof(int));
}

	for(i=0;i<Ra;i++)
		for(j=0;j<Ca;j++){
		scanf("%d",&a[i][j]);}
	scanf("%d%d",&Rb,&Cb);
	int **b = malloc(Rb * sizeof(int*));
    for (i = 0; i < Rb; i++) {
    b[i] = malloc(Cb * sizeof(int));
}
	
	for(i=0;i<Rb;i++)
		for(j=0;j<Cb;j++){
		scanf("%d",&b[i][j]);}	
	if(Ca!=Rb){
		printf("Error: Ca != Rb");
	}
	else{
		printf("%d %d\n",Ra,Cb); 
		int **c = malloc(Ra * sizeof(int*));
for (i = 0; i < Ra; i++) {
    c[i] = malloc(Cb * sizeof(int));
}

		int sum;int k;
		for(i=0;i<Ra;i++){
			for(j=0;j<Cb;j++){
				sum=0;
				for(k=0;k<Ca;k++){
					sum+=a[i][k]*b[k][j];
				}
				c[i][j]=sum;
			}
		}
		for(i=0;i<Ra;i++){
			printf("%d",c[i][0]);
			for(j=1;j<Cb;j++){
			printf(" %d",c[i][j]); 
			}
			printf("\n");}
		} 
	}
