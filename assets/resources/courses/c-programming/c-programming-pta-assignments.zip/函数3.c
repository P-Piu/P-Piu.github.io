#include<stdio.h>
int fn( int a, int n );
int SumA( int a, int n );

int main()
{
    int a, n;

    scanf("%d %d", &a, &n);
    printf("fn(%d, %d) = %d\n", a, n, fn(a,n));        
    printf("s = %d\n", SumA(a,n));    

    return 0;
}

int fn(int a,int n){
	int Tn=0,i,x=1;
	for(i=1;i<=n;i++){
	Tn=Tn+a*x;
	x=x*10;}
	return Tn;
	}
	
int SumA(int a,int n){
	int Tn=0,i,x=1,sum=0;
	for(;n>=1;n--){
	for(i=1;i<=n;i++){
	Tn+=a*x;
	x=x*10;}
	sum+=Tn;
	Tn=0;
	x=1;}
	return sum;
}
