#include <stdio.h>

int factors_sum(int x);

int main(void)
{
    int x;
    scanf("%d", &x);
    while (x != -1)
    {
        printf("%d\n", factors_sum(x));
        scanf("%d", &x);
    }
    return 0;
}

/* ����������д�� */
int factors_sum(int x){
	int i;int sum=0;
	if(x==1)
	  sum=0;
	else{	
	for(i=1;i<=x;i++){
		if(x%i==0&&i!=x){
			sum+=i;	}
	}
	return sum;}
}
