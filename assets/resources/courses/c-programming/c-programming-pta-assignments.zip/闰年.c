#include<stdio.h>
int main(){
	int limit;int year=2001;
	scanf("%d",&limit);
	if (limit>=2004&&limit<=2100){
	while(year<=limit){
	    if((year%4==0&&year%100!=0)||year%400==0)
		printf("%d\n",year);
		year+=1;}
	}
	else if(limit>=2001&&limit<=2003)
	     printf("None");
	else 
	printf("Invalid year!");
}
