#include<stdio.h>
int main(){
	int num,i;
	printf("[1] apple\n[2] pear\n[3] orange\n[4] grape\n[0] exit");
	for (i=1;i<=5;i++)
	{scanf("%d",&num);
    if(num==0)
    break;
	switch(num){
	case 1:printf("price = 3.00");break;
	case 2:printf("price = 2.50");break;
	case 3:printf("price = 4.10");break;
	case 4:printf("price = 10.20");break;
	default:printf("price = 0.00");break;}
	}
	return 0;
}
