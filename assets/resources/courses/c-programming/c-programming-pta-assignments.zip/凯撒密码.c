#include<stdio.h>
#define MAXLINE 80
#define M 26
int main(){
	int i,offset;
	char str[MAXLINE];
	printf("Enter a string:");
	i=0;
	while((str[i]=getchar())!='\n'){
		i++;
	}
	str[i]='\0';
	printf("Enter offset:");
	scanf("%d",&offset);
	if(offset>=M){
		offset=offset%M;
	}
	for(i=0;str[i]!='\0';i++){
		if(str[i]>='A'&&str[i]<='Z'){//�Ǵ�д��ĸ 
		if(str[i]+offset<='Z'){
			str[i]+=offset;
		}
		else str[i]+=offset-M;}
		else if(str[i]>='a'&&str[i]<='z'){
			    if(str[i]+offset<='z'){
			    	str[i]+=offset;
			    }
			    else
			    str[i]+=offset-M;
		}
	}
	puts(str);
    return 0;
}
