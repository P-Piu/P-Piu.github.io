#include<stdio.h>
int main(){
	int N,M;int i;int j;int first=1;
	scanf("%d%d",&N,&M);
	if(M>N){
		M=M%N; 
	}
	int a[N+M];
	for (i=M;i<M+N;i++){
		scanf("%d",&a[i]);
	}
	for (i=N,j=0;i<N+M;i++,j++){
	//	int t=a[i];int f=a[j];
		a[j]=a[i];
	}
	for(i=0;i<N;i++){
		if(first==1){
			printf("%d",a[i]);
			first=0;
			continue;
		}
		printf(" %d",a[i]);
	}
	
}
