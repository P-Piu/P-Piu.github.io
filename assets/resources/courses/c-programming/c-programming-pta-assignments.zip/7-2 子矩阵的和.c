#include<stdio.h>
int main(){
	int n,m,q;int sum;
	int i,j,k;
	int x1,y1,x2,y2;
	scanf("%d%d%d",&n,&m,&q);
	int a[n][m]; 
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(k=0;k<q;k++){
		sum=0;
		scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
		for(i=x1-1;i<=x2-1;i++){
			for(j=y1-1;j<=y2-1;j++){
				sum+=a[i][j];
			}
		}
		printf("%d\n",sum);
	}
	
}
