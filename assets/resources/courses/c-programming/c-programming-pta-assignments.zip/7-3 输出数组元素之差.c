#include<stdio.h>
int main(){
	int N;int i;int count=0;int sub;
	scanf("%d",&N);
	int a[N];
	for(i=0;i<N;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<N-1;i++){
		sub=a[i+1]-a[i];
		count++;
		printf("%d",sub);
		if(count%3==0){
			printf("\n");
		}
		else if(i!=N-2){
			printf(" ");
		}
		
		}
		
	return 0;
	}
