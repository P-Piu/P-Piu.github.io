#include <stdio.h>

int isMultipleOf ( int a, int b );

int main() {
  int a, b;
  scanf("%d%d", &a, &b);
  printf("%d\n", isMultipleOf(a, b));
  return 0;
}

/* ����������д�� */
int isMultipleOf(int a,int b){
    int result;
    if(b==0){
       if(a==0)
       result=1;
       else
       result=0;}
    else
       if(a==-2147483648&&b==-1) 
       result=1;
       else  if(a%b==0)
              result=1;
             else
             result=0;
    return result;}
