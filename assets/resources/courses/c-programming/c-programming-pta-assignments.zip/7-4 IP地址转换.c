#include<stdio.h>
#include<math.h>
int main(){
	int x=0;
	int i;
	char str[33];
	int a[33];
	gets(str);
	for(i=0;i<32;i++){
		a[i]=str[i]-'0';
	}
	for(i=0;i<8;i++){
		x+=a[i]*pow(2,7-i);
	}
	printf("%d.",x);
	x=0;
	for(i=8;i<16;i++){
		x+=a[i]*pow(2,15-i);
	}
	printf("%d.",x);
	x=0;
	for(i=16;i<24;i++){
		x+=a[i]*pow(2,23-i);
	}
	printf("%d.",x);
	x=0;
	for(i=24;i<32;i++){
		x+=a[i]*pow(2,31-i);
	}
	printf("%d",x);
}
