#include<stdio.h>
struct book{
	char name[31];
	double price;
};
int main(){
	int N;
	int i;
	struct book max,min,b;
	scanf("%d",&N);
	getchar();
	for(i=0;i<N;i++){
		gets(b.name);
		scanf("%lf",&b.price);
		getchar();
		if(i==0){
			max=b;
			min=b;
		}
		if(b.price>max.price){
			max=b;
		}
		if(b.price<min.price){
			min=b;
		}
		     
	}
	printf("%.2f, %s\n",max.price,max.name);
	printf("%.2f, %s\n",min.price,min.name);
}

