#include<stdio.h>
#include<math.h>
int main(){
	int su(int n); 
	int N;int i;int t;
	scanf("%d",&N);
	printf("%d = ",N);
	for(i=2;i<=N;i++){
		t=N-i;
		if(su(i)&&su(t))
		{printf("%d + %d",i,N-i);
		break;}
		 
	}
	
}


int su(int n){
	int i,counter=0;double limit;
	if(n==2)
	return 1;
	else {
	      limit=sqrt(n)+1;
	      for(i=2;i<=limit;i++){
	      	if(n%i==0)
	      	break;
	      }
	      if (i>limit)
	      return 1;
	      else
	      return 0;
	}}
