#include<stdio.h>
int isprime(int n);
int main(){
	int n,k;
	int first=1;
	int sum=0;
	scanf("%d%d",&n,&k);
	int count=0;int i=n;
	while(count<k){
			if (isprime(i)){
				if(first==1){
					printf("%d",i);
					first=0;
				}
				else{
				printf("+%d",i);}
				sum+=i;
				count++;
				}
				i--;
			if(i==1){
				break;
			}
				}
	printf("=%d",sum);
	return 0;}
int isprime(int n){
	int i=2;
	if(n==2){
		return 1;
	}
	else{
		for(i=2;i<n;i++){
			if (n%i==0){
				return 0;
			}
		}
		return 1;
	}
}
