#include <stdio.h>

void DnIso(int height, char symbol);

int main()
{
    int n;
    char s;
    scanf("%d %c", &n, &s);
    DnIso(n, s);
    putchar('\n');
    return 0;
}

/* ���ύ�Ĵ��뽫��Ƕ������ */
void DnIso(int height,char symbol){
	int a,i,j,k;
	a=2*height-1;
	for(i=1;i<=height;i++){
	   for(k=1;k<=i-1;k++){
	   	printf(" ");
	   }
	   for(j=1;j<=a;j++){
	   printf("%c",symbol);}
	   printf("\n");
	   a-=2;}
}


