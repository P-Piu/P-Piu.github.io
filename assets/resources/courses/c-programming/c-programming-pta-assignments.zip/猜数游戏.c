#include<stdio.h>
int main(){
	int random;int N;int number;int i;int count=0;int right=0;
	scanf("%d%d",&random,&N);
	for(i=1;i<=N;i++){
		scanf("%d",&number);
		count++;
		if(number<0){
		break;}
		else if(number>random){
			printf("Too big\n");}
			 else if(number<random)
			 {printf("Too small\n");
			 } 
			      else{
		          right=1;
				  break;}}
	if (right==0)
	printf("Game Over");
	else if(count==1)
        	printf("Bingo!");
         else if(count<=3)
              printf("Lucky You!");
              else
              printf("Good Guess!");
    return 0;}
	 
		          
