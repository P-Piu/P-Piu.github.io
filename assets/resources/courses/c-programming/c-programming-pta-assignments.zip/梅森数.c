#include<stdio.h>
#include<math.h>
int main(){
	int n,i;int found=0; int t;
3	;scanf("%d",&n);
	int su(int j);
	for(i=1;i<=n;i++){
		t=pow(2,i)-1;
	   if(su(t))
	   {found+=1;
	   printf("%d\n",t);
	   }
	   }
	   if(found==0)
	   printf("None");
}
int su(int j){
	int i;double counter=0;
	for(i=1;i<=j;i++){
		if(j%i==0)
		counter+=1;
	}
	if (counter==2)
	return 1;
	else 
	return 0;
}
