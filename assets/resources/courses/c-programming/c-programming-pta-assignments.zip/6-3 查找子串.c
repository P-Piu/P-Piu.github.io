#include <stdio.h>
#define MAXS 30

char *search(char *s, char *t);
void ReadString( char s[] ); /* �����ṩ��ϸ�ڲ��� */

int main()
{
    char s[MAXS], t[MAXS], *pos;
    
    ReadString(s);
    ReadString(t);
    pos = search(s, t);
    if ( pos != NULL )
        printf("%d\n", pos - s);
    else
        printf("-1\n");

    return 0;
}

/* ��Ĵ��뽫��Ƕ������ */
char *search(char *s, char *t){
	int i;int j;int k;int findindex;
	for(i=0;s[i]!='\0';i++){
		if(s[i]==t[0]){
			k=i;j=0;
			findindex=1;
			while(t[j]!='\0'){
				if(s[k]!=t[j]){
					findindex=0;
					break;
				}
				k++;j++;
			}
			if (findindex){
				return &s[i];
			}
		}
	}
	return 0;}
	
