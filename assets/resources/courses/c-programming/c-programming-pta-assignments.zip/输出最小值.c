#include<stdio.h>
int main(){
	int number;int min;int n;int i;
	scanf("%d",&n);
	scanf("%d",&number);
	min=number;
	for(i=1;i<=n-1;i++){
		scanf("%d",&number);
		if(number<min)
		min=number;
	}
	printf("min = %d",min);
	return 0;
}
