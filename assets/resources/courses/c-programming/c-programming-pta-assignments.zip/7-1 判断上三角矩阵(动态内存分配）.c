#include<stdio.h>
#include<stdlib.h>
int main(){
	int T;//T������
	int i,j,k;
	int n;
	int **p;
	int flag=1;
	scanf("%d",&T); 
	for(k=0;k<T;k++){
		scanf("%d",&n);
		flag=1;
		if((p=(int**)malloc(n*sizeof(int*)))==NULL){
		    exit(1); }
		for(i=0;i<n;i++){					
				if((p[i]=(int*)malloc(n*sizeof(int)))==NULL){
					exit(1);
				}
		}//��̬�����˶�ά���� 
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&p[i][j]);
			}
		}
		for(i=1;i<n;i++){
			for(j=0;j<i;j++){
				if(p[i][j]!=0){
					printf("NO\n");
					flag=0;
					break;
				}
			}
			if(flag==0){
				break;
			}
		}
		if(flag==1){
			printf("YES\n");}
		for(i=0;i<n;i++){
			free(p[i]);}
		}	
	return 0;
	} 

	
