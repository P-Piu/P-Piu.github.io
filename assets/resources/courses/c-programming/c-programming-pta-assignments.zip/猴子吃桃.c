#include<stdio.h>
int main(){
	int N;int x=1;int i; 
	scanf("%d",&N); 
	for(i=1;i<=N-1;i++){
		x=(x+1)*2;
	}
	printf("%d",x);
	return 0;
}
