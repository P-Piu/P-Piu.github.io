#include<stdio.h>
int main(){
	char str[80];
	int i;
	i=0;
    int result=0;
	int error=0;
	int num;
	char op;
	while((str[i]=getchar())!='=') {
		i++;
	}
	str[i]='\0';
    //����һ��������
    i=0;
	while(str[i]>='0'&&str[i]<='9') {
		result=result*10+(str[i]-'0');
		i++;
	}
	while(str[i]!='\0'){
		op=str[i];
		i++;
		if (op != '+' && op != '-' && op != '*' && op != '/') {
            printf("ERROR\n");
            return 0;}
        num=0;
        if (!(str[i]>='0'&&str[i]<='9')) {// ��������治�����֣��Ƿ�����ʽ
            printf("ERROR\n");
            return 0;
        }
        while(str[i]>='0'&&str[i]<='9') {
		num=num*10+str[i]-'0';
		i++;}
		 if (op == '+') {
            result += num;
        } else if (op == '-') {
            result -= num;
        } else if (op == '*') {
            result *= num;
        } else if (op == '/') {
            if (num == 0) {
                printf("ERROR\n");
                return 0;
            }
            result /= num;
        }
    }
    printf("%d",result);
	return 0;
}
